

import com.future.api.es.external.common.bean.TapAPIExchangeInfo;
import com.future.api.es.external.common.constants.Constants;
import com.future.api.es.external.common.constants.ErrorMsg;
import com.future.api.es.external.trade.TradeApi;
import com.future.api.es.external.trade.bean.TapAPIAccQryReq;
import com.future.api.es.external.trade.bean.TapAPIAccountInfo;
import com.future.api.es.external.trade.bean.TapAPICommodityInfo;
import com.future.api.es.external.trade.bean.TapAPIFillInfo;
import com.future.api.es.external.trade.bean.TapAPIFundData;
import com.future.api.es.external.trade.bean.TapAPIFundReq;
import com.future.api.es.external.trade.bean.TapAPINewOrder;
import com.future.api.es.external.trade.bean.TapAPIOrderActionRsp;
import com.future.api.es.external.trade.bean.TapAPIOrderInfo;
import com.future.api.es.external.trade.bean.TapAPIOrderInfoNotice;
import com.future.api.es.external.trade.bean.TapAPIOrderQryReq;
import com.future.api.es.external.trade.bean.TapAPIPositionProfitNotice;
import com.future.api.es.external.trade.bean.TapAPITradeLoginAuth;
import com.future.api.es.external.trade.bean.TapAPITradeLoginRspInfo;
import com.future.api.es.external.trade.listener.TradeApiAdapter;

public class TradeApiTest {
	private final static String authCode = "67EA896065459BECDFDB924B29CB7DF1946CED32E26C1EAC946CED32E26C1EAC946CED32E26C1EAC946CED32E26C1EAC5211AF9FEE541DDE41BCBAB68D525B0D111A0884D847D57163FF7F329FA574E7946CED32E26C1EAC946CED32E26C1EAC733827B0CE853869ABD9B8F170E14F8847D3EA0BF4E191F5D97B3DFE4CCB1F01842DD2B3EA2F4B20CAD19B8347719B7E20EA1FA7A3D1BFEFF22290F4B5C43E6C520ED5A40EC1D50ACDF342F46A92CCF87AEE6D73542C42EC17818349C7DEDAB0E4DB16977714F873D505029E27B3D57EB92D5BEDA0A710197EB67F94BB1892B30F58A3F211D9C3B3839BE2D73FD08DD776B9188654853DDA57675EBB7D6FBBFC";
	private final static String userNo = "Q810509893";
	private final static String password = "538945";
	private final static String ip = "123.15.58.28";
	private final static short port = (short)8383;

	public static void main(String[] args) throws Exception {
		final TradeApi tradeApi = new TradeApi(authCode, "", true);
		tradeApi.setApiListener(new TradeApiAdapter() {
			
			/**
			 * 连接成功回调通知
			 */
			public void onConnect() {
				System.out.println("连接成功");
			}
			
			/**
			 * API和服务失去连接的回调 <br>
			 * 在API使用过程中主动或者被动与服务器服务失去连接后都会触发此回调通知用户与服务器的连接已经断开。
			 * 
			 * @param reasonCode
			 *            断开原因代码。具体原因请参见错误码列表
			 */
			public void onDisconnected(int reasonCode) {
				System.out.println("断开连接 " + reasonCode);
			}
			
			/**
			 * 通知用户API准备就绪。<br>
			 * 只有用户回调收到此就绪通知时才能进行后续的各种行情数据查询操作。此回调函数是API能否正常工作的标志。<br>
			 * 就绪后才可以进行后续正常操作
			 */
			public void onAPIReady() {
				System.out.println("API初始化完成");
				TapAPIOrderQryReq orderReq = new TapAPIOrderQryReq();
				orderReq.setAccountNo(userNo);
				tradeApi.qryOrder(orderReq); //查询订单
				tradeApi.qryExchange(); //查询交易所
				tradeApi.qryCommodity(); //查询所有品种
				tradeApi.qryAccount(new TapAPIAccQryReq()); //查询账户信息
				tradeApi.qryFund(new TapAPIFundReq("Q810509893")); //查询客户资金
				TapAPINewOrder order = buildOrder();
				tradeApi.insertOrder(order); //发单
			}
			
			private TapAPINewOrder buildOrder() {
				TapAPINewOrder order = new TapAPINewOrder();
				order.setAccountNo(userNo);
				order.setExchangeNo("NYMEX");
				order.setCommodityNo("CL");
				order.setCommodityType('F');
				order.setContractNo("1805");
				order.setOrderPrice(67.50);
				order.setOrderQty(1);
				order.setOrderSide(Constants.TAPI_SIDE_BUY);
				order.setOrderType(Constants.TAPI_ORDER_TYPE_LIMIT);
				return order;
			}
			
			/**
			 * 订单操作应答
			 * 下单、撤单、改单应答。下单都会有次应答回调，如果下单请求结构中没有填写合约或者资金账号，则仅返回错误号。
			 * 撤单、改单错误由应答和OnRtnOrder，成功仅返回OnRtnOrder回调。
			 * sessionID标识请求对应的sessionID，以便确定该笔应答对应的请求。
			 * @param sessionID 请求的会话ID；
			 * @param errorCode 错误码。0 表示成功。
			 * @param info 订单应答具体类型，包含订单操作类型和订单信息。订单信息部分情况下可能为空，如果为空，可以通过SessiuonID找到对应请求获取请求类型。
			 */
			public void onRspOrderAction(int sessionID, int errorCode, TapAPIOrderActionRsp info) {
				if(errorCode == 0) {
					System.out.println(info);
				} else {
					System.out.println("订单操作错误代码： " + errorCode);
				}
			}
			
			/**
			 * 返回新委托。新下的或者其他地方下的推送过来的。<br>
			 * 如果不关注此项内容，可以设定Login时的NoticeIgnoreFlag以屏蔽。
			 * 服务器接收到客户下的委托内容后就会保存起来等待触发，同时向用户回馈一个
			 * 新委托信息说明服务器正确处理了用户的请求，返回的信息中包含了全部的委托信息，
			 * 同时有一个用来标示此委托的委托号。
			 * @param info 指向返回的信息结构体。当errorCode不为0时，info为空。
			*/
			public void onRtnOrder(TapAPIOrderInfoNotice info) {
				System.out.println(info);
			}
			
			/**
			 * 推送来的成交信息<br>
			 * 用户的委托成交后将向用户推送成交信息。
			 * 如果不关注此项内容，可以设定Login时的NoticeIgnoreFlag以屏蔽。
			 * @param info		指向返回的信息结构体。当errorCode不为0时，info为空。
			 */
			public void onRtnFill(TapAPIFillInfo info) {
				System.out.println(info);
			}
			
			/**
			 * 返回资金账户的资金信息
			 * @param sessionID 请求的会话ID；
			 * @param errorCode 错误码。0 表示成功。
			 * @param isLast 	标示是否是最后一批数据；
			 * @param info		指向返回的信息结构体。当errorCode不为0时，info为空。
			 */
			public void onRspQryFund(int sessionID, int errorCode, boolean isLast, TapAPIFundData info) {
				System.out.println(info);
			}
			
			/**
			 * 持仓盈亏通知
			 * @param info		指向返回的信息结构体。当errorCode不为0时，info为空。
			 * @note 如果不关注此项内容，可以设定Login时的NoticeIgnoreFlag以屏蔽。
			 */
			public void onRtnPositionProfit(TapAPIPositionProfitNotice info) {
				System.out.println(info);
			}
			
			/**
			 * 返回查询的委托信息
			 * @param sessionID 请求的会话ID；
			 * @param errorCode 错误码。0 表示成功。
			 * @param isLast 标示是否是最后一批数据；
			 * @param info 指向返回的信息结构体。当errorCode不为0时，info为空。
			 */
			public void onRspQryOrder(int sessionID, int errorCode, boolean isLast, TapAPIOrderInfo infoBytes) {
				if(errorCode != 0) {
					System.out.println("错误" + ErrorMsg.getErrorMsg(errorCode));
				}
				System.out.println(infoBytes);
			}
			
			/**
			 * 返回用户信息<br>
			 * 此回调接口向用户返回查询的资金账号的详细信息。用户有必要将得到的账号编号保存起来，然后在后续的函数调用中使用。
			 * @param sessionID 请求的会话ID；
			 * @param errorCode 错误码。0 表示成功。
			 * @param isLast 标示是否是最后一批数据；
			 * @param info 指向返回的信息结构体。当errorCode不为0时，info为空。
			 */
			public void onRspQryAccount(int sessionID, int errorCode, boolean isLast, TapAPIAccountInfo infoBytes) {
				if(errorCode != 0) {
					System.out.println("错误" + ErrorMsg.getErrorMsg(errorCode));
				}
				System.out.println(infoBytes);
			}
			
			/**
			 * 返回系统中的交易所信息
			 * @param sessionID 请求的会话ID；
			 * @param errorCode 错误码。0 表示成功。
			 * @param isLast 	标示是否是最后一批数据；
			 * @param info		指向返回的信息结构体。当errorCode不为0时，info为空。
			 */
			public void onRspQryExchange(int sessionID, int errorCode, boolean isLast, TapAPIExchangeInfo infoBytes) {
				if(errorCode != 0) {
					System.out.println("错误" + ErrorMsg.getErrorMsg(errorCode));
				}
				System.out.println(infoBytes);
			}
			
			/**
			 * 返回系统中品种信息<br>
			 * 此回调接口用于向用户返回得到的所有品种信息。
			 * @param sessionID 请求的会话ID，和GetAllCommodities()函数返回对应；
			 * @param errorCode 错误码。0 表示成功。
			 * @param isLast 	标示是否是最后一批数据；
			 * @param info		指向返回的信息结构体。当errorCode不为0时，info为空。
			 */
			public void onRspQryCommodity(int sessionID, int errorCode, boolean isLast, TapAPICommodityInfo infoBytes) {
				if(errorCode != 0) {
					System.out.println("错误" + ErrorMsg.getErrorMsg(errorCode));
				}
				System.out.println(infoBytes);
			}
			
			/**
			 * 系统登录过程回调。<br>
			 * 此函数为Login()登录函数的回调，调用Login()成功后建立了链路连接，然后API将向服务器发送登录认证信息，
			 * 登录期间的数据发送情况和登录的回馈信息传递到此回调函数中。
			 * 该回调返回成功，说明用户登录成功。但是不代表API准备完毕。
			 * @param errorCode 返回错误码,0表示成功。
			 * @param loginRspInfo 登陆应答信息，如果errorCode!=0，则loginRspInfo=NULL。
			 */
			public void onRspLogin(int errorCode, TapAPITradeLoginRspInfo info) {
				if(errorCode == 0) {
					System.out.println("登录成功, " + info);
				} else {
					System.out.println("登录失败");
				}
			}
		});
		tradeApi.setHostAddress(ip, port);
		tradeApi.login(new TapAPITradeLoginAuth(userNo, 'N', password, null)); //登录
	}
	
}
